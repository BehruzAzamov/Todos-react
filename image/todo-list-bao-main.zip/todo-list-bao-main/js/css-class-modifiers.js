const cssClassModifiers = {
  classLoaderWrapperNone: "loader-wrapper--none",
  timeout_1000: 1000,
};

export default cssClassModifiers;
